clear variables; close all; clc;



%% Plot Photocurrent
PhotocurrentCone= load("ConePhotocurrent.txt");
PhotocurrentRod = load("RodPhotocurrent.txt");

start = 100;
ending = length(PhotocurrentRod);


figure('Renderer', 'painters', 'Position', [10 10 900 600]);
plot(PhotocurrentRod(start:ending,1)/1000,(PhotocurrentRod(start:ending,2)*(-1000)+40),'LineWidth',2); hold on
plot((PhotocurrentCone(start:ending,1)/1000 - 0.055),(PhotocurrentCone(start:ending,2)*(-1000)+20),'r','LineWidth',2); 

xlim([1 7]); 
xlabel('Time [s]');ylabel('Current [pA]');
title('Photocurrents Generated from Flash Input');
set(gca,'fontweight','bold','fontsize',11);
legend('Rod','Cone');



%% Plot membrane potential of PR
Rod_Vm = load("Rod.txt");
Cone_Vm = load("Cone.txt");

start = 100;
ending = length(Rod_Vm);


figure('Renderer', 'painters', 'Position', [10 10 900 600]); hold on

plot(Rod_Vm(start:ending,1)/1000,Rod_Vm(start:ending,2),'color',[0.4660, 0.6740, 0.1880],'LineWidth',2);

plot(Cone_Vm(start:ending,1)/1000,Cone_Vm(start:ending,2),'color',[0.6660, 0.4740, 0.3880],'LineWidth',2);


xlim([1 7]);ylim([-70 -40]);xlabel('Time [s]'); ylabel('Membrane Potential [mV]');
legend('Rod','Cone');
title('Photoreceptor Potentials');
set(gca,'fontweight','bold','fontsize',11);

%% Plot membrane potential of RBC

RBC_933 = load("RBC_933.txt");
RBC_822 = load("RBC_822.txt");
RBC_1001 = load("RBC_1001.txt");
RBC_1069 = load("RBC_1069.txt");
RBC_1223 = load("RBC_1223.txt");
RBC_1232 = load("RBC_1232.txt");
RBC_1242 = load("RBC_1242.txt");
RBC_1243 = load("RBC_1243.txt");
RBC_1258 = load("RBC_1258.txt");
RBC_1537 = load("RBC_1537.txt");
%RBC_22748 = load("RBC_22748.txt");
RBC_25001 = load("RBC_250001.txt");
RBC_26167 = load("RBC_26167.txt");
RBC_30692 = load("RBC_30692.txt");
RBC_30804 = load("RBC_30804.txt");
%RBC_31982 = load("RBC_31982.txt");

start = 100;

ending = length(RBC_933);

figure('Renderer', 'painters', 'Position', [10 10 900 600]);
plot((RBC_933(start:ending,1))/1000,RBC_933(start:ending,2),'LineWidth',2);
hold on
plot(RBC_822(start:ending,1)/1000,RBC_822(start:ending,2),'LineWidth',2); 
hold on
plot((RBC_1001(start:ending,1))/1000,RBC_1001(start:ending,2),'LineWidth',2); 
hold on
%plot((RBC_1069(start:ending,1))/1000,RBC_1069(start:ending,2),'LineWidth',2);
hold on
plot((RBC_1223(start:ending,1))/1000,RBC_1223(start:ending,2),'LineWidth',2); 
hold on
plot((RBC_1232(start:ending,1))/1000,RBC_1232(start:ending,2),'LineWidth',2); 
hold on
%plot((RBC_1242(start:ending,1))/1000,RBC_1242(start:ending,2),'LineWidth',2);
hold on
%plot((RBC_1243(start:ending,1))/1000,RBC_1243(start:ending,2),'LineWidth',2); 
hold on
%plot(RBC_1258(start:ending,1)/1000,RBC_1258(start:ending,2),'LineWidth',2); 
hold on
%plot((RBC_1537(start:ending,1))/1000,RBC_1537(start:ending,2),'LineWidth',2);
hold on
%plot(RBC_22748(start:ending,1)/1000,RBC_22748(start:ending,2),'LineWidth',2); 
hold on
plot(RBC_25001(start:ending,1)/1000,RBC_25001(start:ending,2),'LineWidth',2); 
hold on
plot(RBC_26167(start:ending,1)/1000,RBC_26167(start:ending,2),'LineWidth',2); 
hold on
plot(RBC_30692(start:ending,1)/1000,RBC_30692(start:ending,2),'LineWidth',2); 
hold on
%plot(RBC_30804(start:ending,1)/1000,RBC_30804(start:ending,2),'LineWidth',2); 
hold on
%plot(RBC_31982(start:ending,1)/1000,RBC_31982(start:ending,2),'LineWidth',2); 

xlim([1.5 7]); %ylim([-35 0]);
xlabel('Time [s]'); ylabel('Membrane Potential [mV]');
legend('RBC 933','RBC 822','RBC 1001','RBC 1069','RBC 1223','RBC 1232','RBC 1242','RBC 1243','RBC 1258','RBC 1537','RBC 25001','RBC 26167','RBC 30692','RBC 30804')
title('Rod Bipolar Cell Response');
set(gca,'fontweight','bold','fontsize',12);


%% Plot membrane potential of AC
%ACold = load("ACold.txt");

AC_69 = load("AC_69.txt");
AC_192 = load("AC_192.txt");
AC_265 = load("AC_265.txt");
AC_262 = load("AC_262.txt");
AC_1685 = load("AC_1685.txt");
AC_2710 = load("AC_2710.txt");
AC_2712 = load("AC_2712.txt");
AC_2713 = load("AC_2713.txt");
start = 100;
ending = length(AC_265);


figure('Renderer', 'painters', 'Position', [10 10 900 600]);

plot(AC_69(start:ending,1)/1000,AC_69(start:ending,2),'LineWidth',2); hold on;

plot(AC_192(start:ending,1)/1000,AC_192(start:ending,2),'LineWidth',2); hold on;

plot(AC_262(start:ending,1)/1000,AC_262(start:ending,2),'LineWidth',2); hold on;

plot(AC_265(start:ending,1)/1000,AC_265(start:ending,2),'LineWidth',2); hold on;

plot(AC_1685(start:ending,1)/1000,AC_1685(start:ending,2),'LineWidth',2); hold on;

plot(AC_2710(start:ending,1)/1000,AC_2710(start:ending,2),'LineWidth',2); hold on;

plot(AC_2712(start:ending,1)/1000,AC_2712(start:ending,2),'LineWidth',2); hold on;

plot(AC_2713(start:ending,1)/1000,AC_2713(start:ending,2),'LineWidth',2); hold on;

legend('AC 69','AC 192','AC 262','AC 265','AC 1685','AC 2710','AC 2712','AC 2713')
title('Aii Amacrine Cell Response'); xlabel('Time [s]'); ylabel('Membrane Potential [mV]');
ylim([-50 -20]);xlim([1.75 2.8]);
set(gca,'fontweight','bold','fontsize',12);

 %figure; hold on; plot(AC_69(:,2));plot(AC_192(:,2));plot(AC_262(:,2));plot(AC_265(:,2));plot(AC_1685(:,2));plot(AC_2710(:,2));plot(AC_2712(:,2));plot(AC_2713(:,2));

VdiffsAll = [AC_69(38000:38000,2)-AC_69(52000:52000,2) AC_192(38000:38000,2)-AC_192(52000:52000,2) AC_262(38000:38000,2)-AC_262(52000:52000,2) AC_265(38000:38000,2)-AC_265(52000:52000,2) AC_1685(38000:38000,2)-AC_1685(52000:52000,2) AC_2710(38000:38000,2)-AC_2710(52000:52000,2) AC_2712(38000:38000,2)-AC_2712(52000:52000,2) AC_2713(38000:38000,2)-AC_2713(52000:52000,2)];
VstartsAll = [AC_69(38000:38000,2) AC_192(38000:38000,2) AC_262(38000:38000,2) AC_265(38000:38000,2) AC_1685(38000:38000,2) AC_2710(38000:38000,2) AC_2712(38000:38000,2) AC_2713(38000:38000,2)];
VendsAll = [AC_69(52000:52000,2) AC_192(52000:52000,2) AC_262(52000:52000,2) AC_265(52000:52000,2) AC_1685(52000:52000,2) AC_2710(52000:52000,2) AC_2712(52000:52000,2) AC_2713(52000:52000,2)];

VdiffsAii = [AC_69(38000:38000,2)-AC_69(52000:52000,2) AC_192(38000:38000,2)-AC_192(52000:52000,2) AC_262(38000:38000,2)-AC_262(52000:52000,2) AC_265(38000:38000,2)-AC_265(52000:52000,2) AC_1685(38000:38000,2)-AC_1685(52000:52000,2) AC_2710(38000:38000,2)-AC_2710(52000:52000,2) AC_2712(38000:38000,2)-AC_2712(52000:52000,2) AC_2713(38000:38000,2)-AC_2713(52000:52000,2)];
VstartsAii = [AC_69(38000:38000,2) AC_192(38000:38000,2) AC_262(38000:38000,2) AC_265(38000:38000,2) AC_1685(38000:38000,2) AC_2710(38000:38000,2) AC_2712(38000:38000,2) AC_2713(38000:38000,2)];
VendsAii = [AC_69(52000:52000,2) AC_192(52000:52000,2) AC_262(52000:52000,2) AC_265(52000:52000,2) AC_1685(52000:52000,2) AC_2710(52000:52000,2) AC_2712(52000:52000,2) AC_2713(52000:52000,2)];

VdiffsRBC = [AC_69(38000:38000,2)-AC_69(52000:52000,2) AC_192(38000:38000,2)-AC_192(52000:52000,2) AC_262(38000:38000,2)-AC_262(52000:52000,2) AC_265(38000:38000,2)-AC_265(52000:52000,2) AC_1685(38000:38000,2)-AC_1685(52000:52000,2) AC_2710(38000:38000,2)-AC_2710(52000:52000,2) AC_2712(38000:38000,2)-AC_2712(52000:52000,2) AC_2713(38000:38000,2)-AC_2713(52000:52000,2)];
VstartsRBC = [AC_69(38000:38000,2) AC_192(38000:38000,2) AC_262(38000:38000,2) AC_265(38000:38000,2) AC_1685(38000:38000,2) AC_2710(38000:38000,2) AC_2712(38000:38000,2) AC_2713(38000:38000,2)];
VendsRBC = [AC_69(52000:52000,2) AC_192(52000:52000,2) AC_262(52000:52000,2) AC_265(52000:52000,2) AC_1685(52000:52000,2) AC_2710(52000:52000,2) AC_2712(52000:52000,2) AC_2713(52000:52000,2)];

VdiffsCBC = [AC_69(38000:38000,2)-AC_69(52000:52000,2) AC_192(38000:38000,2)-AC_192(52000:52000,2) AC_262(38000:38000,2)-AC_262(52000:52000,2) AC_265(38000:38000,2)-AC_265(52000:52000,2) AC_1685(38000:38000,2)-AC_1685(52000:52000,2) AC_2710(38000:38000,2)-AC_2710(52000:52000,2) AC_2712(38000:38000,2)-AC_2712(52000:52000,2) AC_2713(38000:38000,2)-AC_2713(52000:52000,2)];
VstartsCBC = [AC_69(38000:38000,2) AC_192(38000:38000,2) AC_262(38000:38000,2) AC_265(38000:38000,2) AC_1685(38000:38000,2) AC_2710(38000:38000,2) AC_2712(38000:38000,2) AC_2713(38000:38000,2)];
VendsCBC = [AC_69(52000:52000,2) AC_192(52000:52000,2) AC_262(52000:52000,2) AC_265(52000:52000,2) AC_1685(52000:52000,2) AC_2710(52000:52000,2) AC_2712(52000:52000,2) AC_2713(52000:52000,2)];

%spikes_3 = [1 1.3 1.6 1.8 1.9 2.1 2.2 10.3 10.5 10.5 10.5 10.4 10.2 10.2 15.6 15.5 15.5 ];


%%
%Max voltage values

voltagesmax = [max(RBC_933(10000:end,2)) max(RBC_1001(10000:end,2)) max(RBC_1069(10000:end,2)) max(RBC_1223(10000:end,2)) max(RBC_1232(10000:end,2)) max(RBC_1242(10000:end,2)) max(RBC_1537(10000:end,2))];

voltagesmin = [min(RBC_933(10000:end,2)) min(RBC_1001(10000:end,2)) min(RBC_1069(10000:end,2)) min(RBC_1223(10000:end,2)) min(RBC_1232(10000:end,2)) min(RBC_1242(10000:end,2)) min(RBC_1537(10000:end,2))]; 


%voltagesmax = [max(RBC_822(100:end,2)) max(RBC_933(100:end,2)) max(RBC_1001(100:end,2)) max(RBC_1069(100:end,2)) max(RBC_1223(100:end,2)) max(RBC_1232(100:end,2)) max(RBC_1242(100:end,2))...
%    max(RBC_1258(100:end,2)) max(RBC_1537(100:end,2)) max(RBC_22748(100:end,2)) max(RBC_25001(100:end,2)) max(RBC_26167(100:end,2)) max(RBC_30692(100:end,2)) max(RBC_30804(100:end,2)) max(RBC_31982(100:end,2))];

%voltagesmin = [min(RBC_822(100:end,2)) min(RBC_933(100:end,2)) min(RBC_1001(100:end,2)) min(RBC_1069(100:end,2)) min(RBC_1223(100:end,2)) min(RBC_1232(100:end,2)) min(RBC_1242(100:end,2))...
%    min(RBC_1258(100:end,2)) min(RBC_1537(100:end,2)) min(RBC_22748(100:end,2)) min(RBC_25001(100:end,2)) min(RBC_26167(100:end,2)) min(RBC_30692(100:end,2)) min(RBC_30804(100:end,2)) min(RBC_31982(100:end,2))]; 

deltav = voltagesmax - voltagesmin;


[rows, columns] = size(deltav)
sorted_X = reshape(sort(deltav(:), 'descend'), [columns, rows])'
%xaxis = [933 822 30692 1537 30804 25001 1258 1232 1242 1001 26167 22748 1069 1223 31982];

xaxis = [933 1537 1232 1001 1223 1069 1242];
bar(sorted_X)
title('Change in Membrane Potential of Rod Bipolar Cells');
xlabel('Cell ID'); ylabel('Delta_V (mV)'); 

%% Plot membrane potential of CBC

%CBC = load("CBC.txt");
CBC_430 = load("CBC_430.txt");
CBC_298 = load("CBC_298.txt");
CBC_617 = load("CBC_617.txt");
CBC_724 = load("CBC_724.txt");
CBC_740 = load("CBC_740.txt");
CBC_1167 = load("CBC_1167.txt");

start = 100;
ending = length(CBC_430);

figure('Renderer', 'painters', 'Position', [10 10 900 600]);
%plot(CBC(start:ending,1)/1000,CBC(start:ending,2),'r','LineWidth',2); hold on;


plot(CBC_298(start:ending,1)/1000,CBC_298(start:ending,2),'r','LineWidth',2); hold on;
plot(CBC_430(start:ending,1)/1000,CBC_430(start:ending,2),'g','LineWidth',2); hold on;
plot(CBC_617(start:ending,1)/1000,CBC_617(start:ending,2),'b','LineWidth',2); hold on;
plot(CBC_724(start:ending,1)/1000,CBC_724(start:ending,2),'c','LineWidth',2); hold on;
plot(CBC_740(start:ending,1)/1000,CBC_740(start:ending,2),'m','LineWidth',2); hold on;
plot(CBC_1167(start:ending,1)/1000,CBC_1167(start:ending,2),'LineWidth',2); hold on;


plot(CBC_298(38000:52000,2),'r','LineWidth',2); hold on;
CBC_298(75000)-CBC_298(100000)

VdiffsAll = [CBC_298(38000:38000,2)-CBC_298(52000:52000,2) CBC_430(38000:38000,2)-CBC_430(52000:52000,2) CBC_617(38000:38000,2)-CBC_617(52000:52000,2) CBC_724(38000:38000,2)-CBC_724(52000:52000,2) CBC_740(38000:38000,2)-CBC_740(52000:52000,2) CBC_1167(38000:38000,2)-CBC_1167(52000:52000,2)];
VstartsAll = [CBC_298(38000:38000,2) CBC_430(38000:38000,2) CBC_617(38000:38000,2) CBC_724(38000:38000,2) CBC_740(38000:38000,2) CBC_1167(38000:38000,2)];
VendsAll = [CBC_298(52000:52000,2) CBC_430(52000:52000,2) CBC_617(52000:52000,2) CBC_724(52000:52000,2) CBC_740(52000:52000,2) CBC_1167(52000:52000,2)];

VdiffsAii = [CBC_298(38000:38000,2)-CBC_298(52000:52000,2) CBC_430(38000:38000,2)-CBC_430(52000:52000,2) CBC_617(38000:38000,2)-CBC_617(52000:52000,2) CBC_724(38000:38000,2)-CBC_724(52000:52000,2) CBC_740(38000:38000,2)-CBC_740(52000:52000,2) CBC_1167(38000:38000,2)-CBC_1167(52000:52000,2)];
VstartsAii = [CBC_298(38000:38000,2) CBC_430(38000:38000,2) CBC_617(38000:38000,2) CBC_724(38000:38000,2) CBC_740(38000:38000,2) CBC_1167(38000:38000,2)];
VendsAii = [CBC_298(52000:52000,2) CBC_430(52000:52000,2) CBC_617(52000:52000,2) CBC_724(52000:52000,2) CBC_740(52000:52000,2) CBC_1167(52000:52000,2)];

VdiffsRBC = [CBC_298(38000:38000,2)-CBC_298(52000:52000,2) CBC_430(38000:38000,2)-CBC_430(52000:52000,2) CBC_617(38000:38000,2)-CBC_617(52000:52000,2) CBC_724(38000:38000,2)-CBC_724(52000:52000,2) CBC_740(38000:38000,2)-CBC_740(52000:52000,2) CBC_1167(38000:38000,2)-CBC_1167(52000:52000,2)];
VstartsRBC = [CBC_298(38000:38000,2) CBC_430(38000:38000,2) CBC_617(38000:38000,2) CBC_724(38000:38000,2) CBC_740(38000:38000,2) CBC_1167(38000:38000,2)];
VendsRBC = [CBC_298(52000:52000,2) CBC_430(52000:52000,2) CBC_617(52000:52000,2) CBC_724(52000:52000,2) CBC_740(52000:52000,2) CBC_1167(52000:52000,2)];

VdiffsCBC = [CBC_298(38000:38000,2)-CBC_298(52000:52000,2) CBC_430(38000:38000,2)-CBC_430(52000:52000,2) CBC_617(38000:38000,2)-CBC_617(52000:52000,2) CBC_724(38000:38000,2)-CBC_724(52000:52000,2) CBC_740(38000:38000,2)-CBC_740(52000:52000,2) CBC_1167(38000:38000,2)-CBC_1167(52000:52000,2)];
VstartsCBC = [CBC_298(38000:38000,2) CBC_430(38000:38000,2) CBC_617(38000:38000,2) CBC_724(38000:38000,2) CBC_740(38000:38000,2) CBC_1167(38000:38000,2)];
VendsCBC = [CBC_298(52000:52000,2) CBC_430(52000:52000,2) CBC_617(52000:52000,2) CBC_724(52000:52000,2) CBC_740(52000:52000,2) CBC_1167(52000:52000,2)];


xlim([1.5 3]);
ylim([-45 -25]);xlabel('Time [s]'); ylabel('Membrane Potential [mV]');
legend('CBC 298','CBC 430','CBC 617','CBC 724','CBC 740','CBC 1167')
title('ON Cone Bipolar Cell Response');
set(gca,'fontweight','bold','fontsize',12);


%% Plot membrane potential of GC

GC = load("GC_2612.txt");
start = 100;
ending = length(GC);

figure('Renderer', 'painters', 'Position', [10 10 900 600]);
plot(GC(start:ending,1)/1000,GC(start:ending,2),'color',[0.9100 0.4100 0.1700],'LineWidth',2); 
xlim([1.9 4]); 
%xlabel('Time [s]'); ylabel('Membrane Potential [mV]');%title('ON Ganglion Cell Response');
%set(gca,'fontweight','bold','fontsize',12); %legend('GC 2612');

%RGC rates
AllDegen = [76 110 132 148 160 170 178 182 186 190]; 
ConeDegen = [60 98 120 140 150 162 170 176 182 186]; 
GapDegen = [76 108 130 148 158 170 174 182 188 190]; 
Healthy = [62 98 120 140 150 162 170 176 182 186];

%Home
AllDegen = [20 68 96 114 130 142 152 158 166 172];
ConeDegen =  [12 58 88 108 124 138 148 154 162 168]; %7.8.1
GapDegen =  [26 68 98 116 130 142 152 160 166 172];
Healthy =  [12 56 86 112 124 138 146 154 162 168];

a = GC(:,2); %arbc = GCRBC(:,2);  acbc = GCCBC(:,2);  aaii = GCAii(:,2);
figure; plot(a(39000:49500 ,1)); %39000:49900 78800:102000
[loc pks] = findpeaks(a(39000:49500),'MinPeakHeight',-40);
Rate = (length(pks)-1)/0.5 %Hz
%All 190 (old) 190 (new) 190
%Aii 188 (old) 190 (new) 190
%RBC  154 (old) 188 (new) 186
%CBC  184 (old) 186 (new) 186
%0 rods
%5 rods 190 off 5 Hz dies down
%7 rods 190 off 6 Hz
%10 rods 190 off 9 Hz
%15 rods 190  off 11 Hz
%30 rods 190 off 14 Hz
%50 rods 192 off 17 Hz
%100 rods 192 off 19 Hz
%%
x = [2 4 6 8 10 12 14 16 18 20];
figure('Renderer', 'painters', 'Position', [10 10 900 600]); hold on
A = plot(x,AllDegen,'-o','LineWidth',2.5); A.Color = '#7E2F8E';
C = plot(x,ConeDegen,'-o','LineWidth',2.5); C.Color = '#0072BD';
G = plot(x,GapDegen,'-o','LineWidth',2.5); G.Color = '#EDB120';
H = plot(x,Healthy,"--",'LineWidth',2.5); H.Color = '#A2142F';
legend('Cone + GJ Degeneration','Cone Degeneration','GJ Degeneration','Baseline');
set(gca,'fontweight','bold','fontsize',12);
xlabel('Cone Input Strength [pA]'); ylabel('Firing Rate [Hz]');

%%
aberrant = a(10400:19900,1); plot(aberrant)

y = [100 50 30 15 10 7 5];
t = [19 17 14 11 9 6 0];
p = [190 190 190 190 190 190 190]
fig=figure;
left_color = [.5 .5 0];
right_color = [0 .5 .5];
set(fig,'defaultAxesColorOrder',[left_color; right_color]);

yyaxis left
plot(y,t,'LineWidth',1.75); ylabel('RGC Firing Rate [Hz]');
yyaxis right
plot(y,p,'LineWidth',1.75);yticks([189 190 191])
set(gca,'fontweight','bold','fontsize',12); legend('Post-Stimulation ','Peri-Stimulation');
xlabel('Number of Rods per RodBC'); ylabel('RGC Firing Rate [Hz]'); xlim([5 100]);


GC = load("GC_2612_All.txt");
GCRBC = load("GC_2612_RBC.txt");
GCCBC = load("GC_2612_CBC.txt");
GCAii = load("GC_2612_Aii.txt");

figure; hold on
%plot(GC(:,1)/1000,GC(:,2),'LineWidth',2); %15 peaks
%plot(GCRBC(:,1)/1000,GCRBC(:,2),'LineWidth',2); %13 peaks
%plot(GCCBC(:,1)/1000,GCCBC(:,2),'LineWidth',2); %15 peaks
plot(GCAii(:,1)/1000,GCAii(:,2),'LineWidth',2); %13 peaks
legend('All','RBC','CBC','Aii'); xlim([2.6 4]);


%%
% GC spike number vs input in Original
spikes1 = [1 11 21 30 37 43 49 52 57 70 77]; %83 86
input1 = [2 3 4 5 6 7 8 9 10 15 20];
%%
% GC spike number vs input in Healthy Rods
spikes2 = [6 14 25 33 39 46 51 55 59 71 79]; %84 88
input2 = [2 3 4 5 6 7 8 9 10 15 20];

%%
% GC spike number vs input in Heatlhy Rods, with Degeneration
spikes3 = [8 19 30 38 44 49 54 57 61 73 80]; %85 89
input3 = [2 3 4 5 6 7 8 9 10 15 20];

%%
% GC spike number vs input in Healthy Rods, with Cone only Degeneration
spikes4 = [6 12 24 32 38 46 49 53 57 69 77]; % 82 88
input4 = [2 3 4 5 6 7 8 9 10 15 20];

%%
% GC spike number vs input in Healthy Rods, with Gap junction only Degeneration
spikes5 = [9 19 30 38 45 50 54 58 62 74 81]; % 86 90
input5 = [2 3 4 5 6 7 8 9 10 15 20];

figure
plot(input2,spikes2,'LineWidth',2.5)
hold on
plot(input3,spikes3,'LineWidth',2.5)
hold on
plot(input4,spikes4,'LineWidth',2.5)
hold on
plot(input5,spikes5,'LineWidth',2.5)

title('Ganglion Cell Spikes Observed During Stimulation'); xlabel('Cone Input Strength (pA)');ylabel('Spike Number')
legend('Healthy RPC1 (Full rods, no degeneration)','Full RPC1 with degeneration','Cone only degeneration','GJ only degeneration')
set(gca,'fontweight','bold','fontsize',12); xlim([2 20]);


%%
%Percentage Diff Bar plot

%Diff1 = spikes1-spikes2;
%Percent1 = 100*Diff1./spikes2
%Diff2 = spikes3-spikes2;
%Percent2 = 100*Diff2./spikes2 
%Diff3 = spikes4-spikes2;
%Percent3 = 100*Diff3./spikes2
%Diff4 = spikes5-spikes2;
%Percent4 = 100*Diff4./spikes2

%Revised
Diff1 = ConeDegen-Healthy; %Cone
Percent1 = 100*Diff1./Healthy
Diff2 = GapDegen-Healthy; %Gap
Percent2 = 100*Diff2./Healthy 
Diff3 = AllDegen-Healthy; %All
Percent3 = 100*Diff3./Healthy
y = 0;
conesat = [10 20 30 40 50 60 70 80 90 100];
figure; hold on
b3 = bar(conesat,Percent3); b3.FaceColor = '#7E2F8E'; alpha(b3,1)
b1 = bar(conesat,Percent1); b1.FaceColor = '#0072BD'; 
b2 = bar(conesat,Percent2); b2.FaceColor = '#EDB120'; alpha(b2,0.75)
b4 = line([-10,120],[y,y]); b4.Color = '#A2142F'; b4.LineWidth = 2;
set(gca,'fontweight','bold','fontsize',12); xlim([0 110]);


title('Comparison of RGC Firing Rates (vs. Baseline)'); xlabel('Cone Photocurrent Saturation (%)');ylabel('Difference (%)')
legend('Cone + GJ Degeneration','Cone Degeneration','GJ Degeneration','Baseline')

%%
% Anlaysis points

%1. Gc spike rate
%2. Healthy vs. degen potential plots.
%3. Corruption of rod pathway (zero rod input, RBC potential)
%4. Cell size vs. resting potential