/* Created by Language version: 7.7.0 */
/* VECTORIZED */
#define NRN_VECTORIZED 1
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "scoplib_ansi.h"
#undef PI
#define nil 0
#include "md1redef.h"
#include "section.h"
#include "nrniv_mf.h"
#include "md2redef.h"
 
#if METHOD3
extern int _method3;
#endif

#if !NRNGPU
#undef exp
#define exp hoc_Exp
extern double hoc_Exp(double);
#endif
 
#define nrn_init _nrn_init__IT
#define _nrn_initial _nrn_initial__IT
#define nrn_cur _nrn_cur__IT
#define _nrn_current _nrn_current__IT
#define nrn_jacob _nrn_jacob__IT
#define nrn_state _nrn_state__IT
#define _net_receive _net_receive__IT 
#define rates rates__IT 
#define states states__IT 
 
#define _threadargscomma_ _p, _ppvar, _thread, _nt,
#define _threadargsprotocomma_ double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt,
#define _threadargs_ _p, _ppvar, _thread, _nt
#define _threadargsproto_ double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt
 	/*SUPPRESS 761*/
	/*SUPPRESS 762*/
	/*SUPPRESS 763*/
	/*SUPPRESS 765*/
	 extern double *getarg();
 /* Thread safe. No static _p or _ppvar. */
 
#define t _nt->_t
#define dt _nt->_dt
#define gTbar _p[0]
#define Erev _p[1]
#define V_s _p[2]
#define i _p[3]
#define g _p[4]
#define k _p[5]
#define alpha_1 _p[6]
#define alpha_2 _p[7]
#define beta_1 _p[8]
#define beta_2 _p[9]
#define m _p[10]
#define h _p[11]
#define d _p[12]
#define ica _p[13]
#define Dm _p[14]
#define Dh _p[15]
#define Dd _p[16]
#define v _p[17]
#define _g _p[18]
#define _ion_ica	*_ppvar[0]._pval
#define _ion_dicadv	*_ppvar[1]._pval
 
#if MAC
#if !defined(v)
#define v _mlhv
#endif
#if !defined(h)
#define h _mlhh
#endif
#endif
 
#if defined(__cplusplus)
extern "C" {
#endif
 static int hoc_nrnpointerindex =  -1;
 static Datum* _extcall_thread;
 static Prop* _extcall_prop;
 /* external NEURON variables */
 /* declaration of user functions */
 static void _hoc_minf(void);
 static void _hoc_rates(void);
 static void _hoc_taum(void);
 static int _mechtype;
extern void _nrn_cacheloop_reg(int, int);
extern void hoc_register_prop_size(int, int, int);
extern void hoc_register_limits(int, HocParmLimits*);
extern void hoc_register_units(int, HocParmUnits*);
extern void nrn_promote(Prop*, int, int);
extern Memb_func* memb_func;
 
#define NMODL_TEXT 1
#if NMODL_TEXT
static const char* nmodl_file_text;
static const char* nmodl_filename;
extern void hoc_reg_nmodl_text(int, const char*);
extern void hoc_reg_nmodl_filename(int, const char*);
#endif

 extern void _nrn_setdata_reg(int, void(*)(Prop*));
 static void _setdata(Prop* _prop) {
 _extcall_prop = _prop;
 }
 static void _hoc_setdata() {
 Prop *_prop, *hoc_getdata_range(int);
 _prop = hoc_getdata_range(_mechtype);
   _setdata(_prop);
 hoc_retpushx(1.);
}
 /* connect user functions to hoc names */
 static VoidFunc hoc_intfunc[] = {
 "setdata_IT", _hoc_setdata,
 "minf_IT", _hoc_minf,
 "rates_IT", _hoc_rates,
 "taum_IT", _hoc_taum,
 0, 0
};
#define minf minf_IT
#define taum taum_IT
 extern double minf( _threadargsprotocomma_ double );
 extern double taum( _threadargsprotocomma_ double );
 /* declare global and static user variables */
 /* some parameters have upper and lower limits */
 static HocParmLimits _hoc_parm_limits[] = {
 "gTbar_IT", 0, 1e+009,
 0,0,0
};
 static HocParmUnits _hoc_parm_units[] = {
 "gTbar_IT", "S/cm2",
 "Erev_IT", "mV",
 "V_s_IT", "mV",
 "i_IT", "mA/cm2",
 "g_IT", "S/cm2",
 "alpha_1_IT", "1",
 "alpha_2_IT", "1",
 "beta_1_IT", "1",
 "beta_2_IT", "1",
 0,0
};
 static double delta_t = 0.01;
 static double d0 = 0;
 static double h0 = 0;
 static double m0 = 0;
 /* connect global user variables to hoc */
 static DoubScal hoc_scdoub[] = {
 0,0
};
 static DoubVec hoc_vdoub[] = {
 0,0,0
};
 static double _sav_indep;
 static void nrn_alloc(Prop*);
static void  nrn_init(_NrnThread*, _Memb_list*, int);
static void nrn_state(_NrnThread*, _Memb_list*, int);
 static void nrn_cur(_NrnThread*, _Memb_list*, int);
static void  nrn_jacob(_NrnThread*, _Memb_list*, int);
 
static int _ode_count(int);
static void _ode_map(int, double**, double**, double*, Datum*, double*, int);
static void _ode_spec(_NrnThread*, _Memb_list*, int);
static void _ode_matsol(_NrnThread*, _Memb_list*, int);
 
#define _cvode_ieq _ppvar[2]._i
 static void _ode_matsol_instance1(_threadargsproto_);
 /* connect range variables in _p that hoc is supposed to know about */
 static const char *_mechanism[] = {
 "7.7.0",
"IT",
 "gTbar_IT",
 "Erev_IT",
 "V_s_IT",
 0,
 "i_IT",
 "g_IT",
 "k_IT",
 "alpha_1_IT",
 "alpha_2_IT",
 "beta_1_IT",
 "beta_2_IT",
 0,
 "m_IT",
 "h_IT",
 "d_IT",
 0,
 0};
 static Symbol* _ca_sym;
 
extern Prop* need_memb(Symbol*);

static void nrn_alloc(Prop* _prop) {
	Prop *prop_ion;
	double *_p; Datum *_ppvar;
 	_p = nrn_prop_data_alloc(_mechtype, 19, _prop);
 	/*initialize range parameters*/
 	gTbar = 0.0004;
 	Erev = 120;
 	V_s = 0;
 	_prop->param = _p;
 	_prop->param_size = 19;
 	_ppvar = nrn_prop_datum_alloc(_mechtype, 3, _prop);
 	_prop->dparam = _ppvar;
 	/*connect ionic variables to this model*/
 prop_ion = need_memb(_ca_sym);
 	_ppvar[0]._pval = &prop_ion->param[3]; /* ica */
 	_ppvar[1]._pval = &prop_ion->param[4]; /* _ion_dicadv */
 
}
 static void _initlists();
  /* some states have an absolute tolerance */
 static Symbol** _atollist;
 static HocStateTolerance _hoc_state_tol[] = {
 0,0
};
 static void _update_ion_pointer(Datum*);
 extern Symbol* hoc_lookup(const char*);
extern void _nrn_thread_reg(int, int, void(*)(Datum*));
extern void _nrn_thread_table_reg(int, void(*)(double*, Datum*, Datum*, _NrnThread*, int));
extern void hoc_register_tolerance(int, HocStateTolerance*, Symbol***);
extern void _cvode_abstol( Symbol**, double*, int);

 void _GC_IT_reg() {
	int _vectorized = 1;
  _initlists();
 	ion_reg("ca", -10000.);
 	_ca_sym = hoc_lookup("ca_ion");
 	register_mech(_mechanism, nrn_alloc,nrn_cur, nrn_jacob, nrn_state, nrn_init, hoc_nrnpointerindex, 1);
 _mechtype = nrn_get_mechtype(_mechanism[1]);
     _nrn_setdata_reg(_mechtype, _setdata);
     _nrn_thread_reg(_mechtype, 2, _update_ion_pointer);
 #if NMODL_TEXT
  hoc_reg_nmodl_text(_mechtype, nmodl_file_text);
  hoc_reg_nmodl_filename(_mechtype, nmodl_filename);
#endif
  hoc_register_prop_size(_mechtype, 19, 3);
  hoc_register_dparam_semantics(_mechtype, 0, "ca_ion");
  hoc_register_dparam_semantics(_mechtype, 1, "ca_ion");
  hoc_register_dparam_semantics(_mechtype, 2, "cvodeieq");
 	hoc_register_cvode(_mechtype, _ode_count, _ode_map, _ode_spec, _ode_matsol);
 	hoc_register_tolerance(_mechtype, _hoc_state_tol, &_atollist);
 	hoc_register_var(hoc_scdoub, hoc_vdoub, hoc_intfunc);
 	ivoc_help("help ?1 IT D:/Cone_CBC_GC on off sims_allCBCs_includeDarkCurrent/GC_IT.mod\n");
 hoc_register_limits(_mechtype, _hoc_parm_limits);
 hoc_register_units(_mechtype, _hoc_parm_units);
 }
static int _reset;
static char *modelname = "";

static int error;
static int _ninits = 0;
static int _match_recurse=1;
static void _modl_cleanup(){ _match_recurse=1;}
static int rates(_threadargsprotocomma_ double);
 
static int _ode_spec1(_threadargsproto_);
/*static int _ode_matsol1(_threadargsproto_);*/
 static int _slist1[3], _dlist1[3];
 static int states(_threadargsproto_);
 
/*CVODE*/
 static int _ode_spec1 (double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) {int _reset = 0; {
   rates ( _threadargscomma_ v ) ;
   Dm = ( minf ( _threadargscomma_ v ) - m ) / taum ( _threadargscomma_ v ) ;
   Dh = alpha_1 * ( 1.0 - h - d ) - beta_1 * h ;
   Dd = beta_2 * ( 1.0 - h - d ) - alpha_2 * d ;
   }
 return _reset;
}
 static int _ode_matsol1 (double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) {
 rates ( _threadargscomma_ v ) ;
 Dm = Dm  / (1. - dt*( ( ( ( - 1.0 ) ) ) / taum ( _threadargscomma_ v ) )) ;
 Dh = Dh  / (1. - dt*( ( alpha_1 )*( ( ( - 1.0 ) ) ) - ( beta_1 )*( 1.0 ) )) ;
 Dd = Dd  / (1. - dt*( ( beta_2 )*( ( ( - 1.0 ) ) ) - ( alpha_2 )*( 1.0 ) )) ;
  return 0;
}
 /*END CVODE*/
 static int states (double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) { {
   rates ( _threadargscomma_ v ) ;
    m = m + (1. - exp(dt*(( ( ( - 1.0 ) ) ) / taum ( _threadargscomma_ v ))))*(- ( ( ( minf ( _threadargscomma_ v ) ) ) / taum ( _threadargscomma_ v ) ) / ( ( ( ( - 1.0 ) ) ) / taum ( _threadargscomma_ v ) ) - m) ;
    h = h + (1. - exp(dt*(( alpha_1 )*( ( ( - 1.0 ) ) ) - ( beta_1 )*( 1.0 ))))*(- ( ( alpha_1 )*( ( 1.0 - d ) ) ) / ( ( alpha_1 )*( ( ( - 1.0 ) ) ) - ( beta_1 )*( 1.0 ) ) - h) ;
    d = d + (1. - exp(dt*(( beta_2 )*( ( ( - 1.0 ) ) ) - ( alpha_2 )*( 1.0 ))))*(- ( ( beta_2 )*( ( 1.0 - h ) ) ) / ( ( beta_2 )*( ( ( - 1.0 ) ) ) - ( alpha_2 )*( 1.0 ) ) - d) ;
   }
  return 0;
}
 
double minf ( _threadargsprotocomma_ double _lVm ) {
   double _lminf;
 _lminf = 1.0 / ( 1.0 + exp ( - ( _lVm + V_s + 63.0 ) / 7.8 ) ) ;
   
return _lminf;
 }
 
static void _hoc_minf(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  minf ( _p, _ppvar, _thread, _nt, *getarg(1) );
 hoc_retpushx(_r);
}
 
double taum ( _threadargsprotocomma_ double _lVm ) {
   double _ltaum;
 _ltaum = ( 1.7 + exp ( - ( _lVm + V_s + 28.8 ) / 13.5 ) ) / ( 1.0 + exp ( - ( _lVm + V_s + 63.0 ) / 7.8 ) ) ;
   
return _ltaum;
 }
 
static void _hoc_taum(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  taum ( _p, _ppvar, _thread, _nt, *getarg(1) );
 hoc_retpushx(_r);
}
 
static int  rates ( _threadargsprotocomma_ double _lVm ) {
   double _ltau_2 ;
 k = pow( ( 0.25 + exp ( ( _lVm + V_s + 83.5 ) / 6.3 ) ) , 0.5 ) - 0.5 ;
   _ltau_2 = 240.0 / ( 1.0 + exp ( ( _lVm + V_s + 37.4 ) / 30.0 ) ) ;
   alpha_1 = exp ( - ( _lVm + V_s + 160.3 ) / 17.8 ) ;
   beta_1 = k * alpha_1 ;
   alpha_2 = 1.0 / ( _ltau_2 * ( 1.0 + k ) ) ;
   beta_2 = k * alpha_2 ;
    return 0; }
 
static void _hoc_rates(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r = 1.;
 rates ( _p, _ppvar, _thread, _nt, *getarg(1) );
 hoc_retpushx(_r);
}
 
static int _ode_count(int _type){ return 3;}
 
static void _ode_spec(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   double* _p; Datum* _ppvar; Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
     _ode_spec1 (_p, _ppvar, _thread, _nt);
  }}
 
static void _ode_map(int _ieq, double** _pv, double** _pvdot, double* _pp, Datum* _ppd, double* _atol, int _type) { 
	double* _p; Datum* _ppvar;
 	int _i; _p = _pp; _ppvar = _ppd;
	_cvode_ieq = _ieq;
	for (_i=0; _i < 3; ++_i) {
		_pv[_i] = _pp + _slist1[_i];  _pvdot[_i] = _pp + _dlist1[_i];
		_cvode_abstol(_atollist, _atol, _i);
	}
 }
 
static void _ode_matsol_instance1(_threadargsproto_) {
 _ode_matsol1 (_p, _ppvar, _thread, _nt);
 }
 
static void _ode_matsol(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   double* _p; Datum* _ppvar; Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
 _ode_matsol_instance1(_threadargs_);
 }}
 extern void nrn_update_ion_pointer(Symbol*, Datum*, int, int);
 static void _update_ion_pointer(Datum* _ppvar) {
   nrn_update_ion_pointer(_ca_sym, _ppvar, 0, 3);
   nrn_update_ion_pointer(_ca_sym, _ppvar, 1, 4);
 }

static void initmodel(double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) {
  int _i; double _save;{
  d = d0;
  h = h0;
  m = m0;
 {
   double _lC , _lE ;
 rates ( _threadargscomma_ v ) ;
   m = minf ( _threadargscomma_ v ) ;
   _lC = beta_1 / alpha_1 ;
   _lE = alpha_2 / beta_2 ;
   h = _lE / ( _lE * _lC + _lE + _lC ) ;
   d = 1.0 - ( 1.0 + _lC ) * h ;
   }
 
}
}

static void nrn_init(_NrnThread* _nt, _Memb_list* _ml, int _type){
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 v = _v;
 initmodel(_p, _ppvar, _thread, _nt);
 }
}

static double _nrn_current(double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt, double _v){double _current=0.;v=_v;{ {
   g = gTbar * pow( m , 3.0 ) * h ;
   ica = g * ( v - Erev ) ;
   i = ica ;
   }
 _current += ica;

} return _current;
}

static void nrn_cur(_NrnThread* _nt, _Memb_list* _ml, int _type) {
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; double _rhs, _v; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 _g = _nrn_current(_p, _ppvar, _thread, _nt, _v + .001);
 	{ double _dica;
  _dica = ica;
 _rhs = _nrn_current(_p, _ppvar, _thread, _nt, _v);
  _ion_dicadv += (_dica - ica)/.001 ;
 	}
 _g = (_g - _rhs)/.001;
  _ion_ica += ica ;
#if CACHEVEC
  if (use_cachevec) {
	VEC_RHS(_ni[_iml]) -= _rhs;
  }else
#endif
  {
	NODERHS(_nd) -= _rhs;
  }
 
}
 
}

static void nrn_jacob(_NrnThread* _nt, _Memb_list* _ml, int _type) {
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml];
#if CACHEVEC
  if (use_cachevec) {
	VEC_D(_ni[_iml]) += _g;
  }else
#endif
  {
     _nd = _ml->_nodelist[_iml];
	NODED(_nd) += _g;
  }
 
}
 
}

static void nrn_state(_NrnThread* _nt, _Memb_list* _ml, int _type) {
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; double _v = 0.0; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
 _nd = _ml->_nodelist[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 v=_v;
{
 {   states(_p, _ppvar, _thread, _nt);
  } }}

}

static void terminal(){}

static void _initlists(){
 double _x; double* _p = &_x;
 int _i; static int _first = 1;
  if (!_first) return;
 _slist1[0] = &(m) - _p;  _dlist1[0] = &(Dm) - _p;
 _slist1[1] = &(h) - _p;  _dlist1[1] = &(Dh) - _p;
 _slist1[2] = &(d) - _p;  _dlist1[2] = &(Dd) - _p;
_first = 0;
}

#if defined(__cplusplus)
} /* extern "C" */
#endif

#if NMODL_TEXT
static const char* nmodl_filename = "GC_IT.mod";
static const char* nmodl_file_text = 
  "COMMENT\n"
  "This T-type calcium current was originally reported in Wang XJ et al 1991\n"
  "This file supplies a version of this current identical to Quadroni and Knopfel 1994\n"
  "except for gbar and Erev (see notes below).\n"
  "ENDCOMMENT\n"
  "\n"
  "NEURON {\n"
  "	SUFFIX IT\n"
  "	: NONSPECIFIC_CURRENT i\n"
  "	USEION ca WRITE  ica\n"
  "	RANGE Erev,g, gTbar, i\n"
  "	RANGE k, taum, minf, alpha_1, alpha_2, beta_1, beta_2, V_s\n"
  "}\n"
  "\n"
  "UNITS {\n"
  "	(S)	=	(siemens)\n"
  "	(mV)	=	(millivolt)\n"
  "	(mA)	=	(milliamp)\n"
  "}\n"
  "\n"
  "PARAMETER {\n"
  "	gTbar = 0.4e-3	(S/cm2) < 0, 1e9 > : Quadroni and Knopfel use 166e-6\n"
  "	Erev = 120 (mV)	: orig from Wang XJ et al 1991 was 120\n"
  "	: note: Quadroni and Knopfel 1994 table 1 use 80 instead\n"
  "	V_s = 0 (mV)	: used to describe effect of changing extracellular [Ca]\n"
  "			: 0 corresponds to [Ca]outside = 3 mM (p 841)\n"
  "}\n"
  "\n"
  "ASSIGNED {\n"
  "	ica (mA/cm2)\n"
  "	i (mA/cm2)\n"
  "	v (mV)\n"
  "	g (S/cm2)\n"
  "	k\n"
  "	alpha_1 (1)\n"
  "	alpha_2	(1)\n"
  "	beta_1 (1)\n"
  "	beta_2 (1)\n"
  "}\n"
  "\n"
  "STATE {	m h d }\n"
  "\n"
  "BREAKPOINT {\n"
  "	SOLVE states METHOD cnexp\n"
  "	g = gTbar * m^3 * h\n"
  "	ica = g * (v - Erev)\n"
  "	i = ica	: used only to display the value of the current (section.i_lva(0.5))\n"
  "}\n"
  "\n"
  "INITIAL {\n"
  "	LOCAL C, E\n"
  "	: assume that v has been constant for a long time\n"
  "	: (derivable from rate equations in DERIVATIVE block at equilibrium)\n"
  "	rates(v)\n"
  "	m = minf(v)\n"
  "	: h and d are intertwined so more complex than above equilib state for m\n"
  "	C =  beta_1 / alpha_1\n"
  "	E =  alpha_2 / beta_2\n"
  "	h = E / (E * C + E + C)\n"
  "	d = 1 - (1 + C) * h\n"
  "}\n"
  "\n"
  "DERIVATIVE states{ \n"
  "	rates(v)\n"
  "	m' = (minf(v) - m)/taum(v)		: alpham(v) * (1 - m) - betam(v) * m\n"
  "	h' = alpha_1 * (1 - h - d) - beta_1 * h\n"
  "	d' =  beta_2 * (1 - h - d) - alpha_2 * d\n"
  "}\n"
  "\n"
  "FUNCTION minf(Vm (mV)) (1) {\n"
  "	minf = 1.0 / (1.0 + exp(-(Vm + V_s + 63)/7.8))\n"
  "}\n"
  "\n"
  "FUNCTION taum(Vm (mV)) (ms) {\n"
  "	taum = (1.7 + exp( -(Vm + V_s + 28.8)/13.5 )) / (1.0 + exp( -(Vm + V_s + 63)/7.8) )\n"
  "}\n"
  "\n"
  "PROCEDURE rates(Vm(mV)) { LOCAL tau_2\n"
  "	k = (0.25 + exp((Vm + V_s + 83.5)/6.3))^0.5 - 0.5\n"
  "	tau_2 = 240.0 / (1 + exp((Vm + V_s + 37.4)/30)) : same as tau2 p 842 equation (15)\n"
  "	alpha_1 = exp( -(Vm + V_s +160.3)/17.8 )	: p 842  equation (14)\n"
  "	beta_1 = k * alpha_1\n"
  "	alpha_2 = 1.0 / ( tau_2 * (1.0 + k) )\n"
  "	beta_2 = k * alpha_2\n"
  "}\n"
  ;
#endif
