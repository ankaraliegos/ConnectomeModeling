clear variables; clc; %close all;

%% Parameters
BC_id = 298;
Nsynapse = 15;
PR_ids = (100000+(1:Nsynapse))';

PR_L = 1;
PR_r = 1;
SynapseType = 73;
SynapseWeight = 1;
SynapseLengthZ = 0.5;
Synapse_Zoffset = 0;

%% Read Bipolar cell morphology and Seperate soma, axon and dendrite, if not already seperated
BC_morph = load(sprintf("%i_withSomaAxonDend.swc",BC_id));
% % separate soma
% counter = 0;
% for i=1:size(BC_morph,1)
%     if(BC_morph(i,2)==1)
%         counter = counter+1;
%     end
% end
% BC_soma = zeros(counter,7);
% count = 0;
% for i=1:size(BC_morph,1)
%     if(BC_morph(i,2)==1)
%         count = count+1;
%         BC_soma(count,:) = BC_morph(i,:);
%     end
% end
% % find minZ and maxZ of soma
% soma_minZ = min(BC_soma(:,5));
% soma_maxZ = max(BC_soma(:,5));
% % Assign dendrite for rows with Z < minZ and axon for rows with Z > maxZ
% for i=1:size(BC_morph,1)
%     if(BC_morph(i,2)~=1)&&(BC_morph(i,5)<soma_minZ)
%         BC_morph(i,2) = 2;
%     end
% end
% % write new file
% BC_morph(:,3)=BC_morph(:,3)+50;
% dlmwrite(sprintf("%i_new.swc",BC_id),BC_morph,'delimiter',' ','precision',12);

%% Plot projection of dendrite tree in XY-plane
counter = 0;
for i=1:size(BC_morph,1)
    if(BC_morph(i,2)==3)
        counter = counter+1;
    end
end
BC_dendrite = zeros(counter,7);
count = 0;
for i=1:size(BC_morph,1)
    if(BC_morph(i,2)==3)
        count = count+1;
        BC_dendrite(count,:) = BC_morph(i,:);
    end
end
figure(1);scatter(BC_dendrite(:,3),BC_dendrite(:,4));
figure(2);scatter(BC_dendrite(:,3),BC_dendrite(:,4)); hold on;

%% Pick random locations (for synapse locations) in dendrite tree projection
random_locations = round(rand([Nsynapse 1])*size(BC_dendrite,1));
synapse_locations = zeros(Nsynapse,7);
for i=1:Nsynapse
    synapse_locations(i,:) = BC_dendrite(random_locations(i),:);
end
scatter(synapse_locations(:,3),synapse_locations(:,4),'r'); hold off;

figure(3);
scatter3(BC_morph(:,3),BC_morph(:,4),BC_morph(:,5)); hold on;
scatter3(synapse_locations(:,3),synapse_locations(:,4),synapse_locations(:,5),'r'); hold off;

%% Write PR-BC synapse info file
Target_xyz = [synapse_locations(:,3),synapse_locations(:,4),synapse_locations(:,5)-Synapse_Zoffset];
Source_xyz = [Target_xyz(:,1),Target_xyz(:,2),Target_xyz(:,3)-SynapseLengthZ];
Synapse_Matrix = [PR_ids BC_id*ones(Nsynapse,1) Source_xyz Target_xyz ...
                  SynapseType*ones(Nsynapse,1) SynapseWeight*ones(Nsynapse,1)];
dlmwrite(sprintf('%i_synapse.txt',BC_id),Synapse_Matrix,'delimiter','\t','precision',6);

%% Write PR (single compartment) morphologies (attached to PR-BC synapses)
for i=1:Nsynapse
    PR_Matrix = [1 1 Source_xyz(i,1) Source_xyz(i,2) Source_xyz(i,3) PR_r -1;...
                 2 1 Source_xyz(i,1) Source_xyz(i,2) Source_xyz(i,3)-PR_L PR_r 1];
    dlmwrite(sprintf('%i.swc',PR_ids(i)),PR_Matrix,'delimiter',' ');
end