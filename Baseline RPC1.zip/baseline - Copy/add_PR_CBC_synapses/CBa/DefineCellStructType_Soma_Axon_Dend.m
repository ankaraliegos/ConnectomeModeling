clear variables; clc; close all;

%% Cell number
BC_id = 31996;

dend_type_id = 3;
axon_type_id = 2;

%% Read Bipolar cell morphology and Seperate soma, axon and dendrite
BC_morph = load(sprintf("%i_new2.swc",BC_id));

% separate soma
counter = 0;
for i=1:size(BC_morph,1)
    if(BC_morph(i,2)==1)
        counter = counter+1;
    end
end
BC_soma = zeros(counter,7);
count = 0;
for i=1:size(BC_morph,1)
    if(BC_morph(i,2)==1)
        count = count+1;
        BC_soma(count,:) = BC_morph(i,:);
    end
end

% find minZ and maxZ of soma
soma_minZ = min(BC_soma(:,5));
soma_maxZ = max(BC_soma(:,5));

% Assign axon for annotations with Z > maxZ
for i=1:size(BC_morph,1)
    if(BC_morph(i,2)~=1)&&(BC_morph(i,5)>soma_maxZ)
        BC_morph(i,2) = axon_type_id;
    end
end

% write new file
dlmwrite(sprintf("%i_withSomaAxonDend.swc",BC_id),BC_morph,'delimiter',' ','precision',12);